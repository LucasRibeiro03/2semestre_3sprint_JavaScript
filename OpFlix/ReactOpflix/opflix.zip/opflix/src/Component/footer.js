import React from "react";

function footer() {
    return (
        <footer className="rodape">
            <h2 id="h2footer">Opflix</h2>
            <div>
               <p>Todos os direitos reservados ao ribeiro</p>
               
               <p>esse site é meramente ilustrativo</p>
               
               <p>por favor, não copie !!</p>

            </div>
        </footer>
    );
}

export default footer;